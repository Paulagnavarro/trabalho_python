from flask import render_template, redirect, url_for, request
from config import app, db
from models import load_user, User, Tarefa
from flask_login import login_required, login_user, logout_user, current_user
from forms import TarefaForm


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    from forms import RegisterForm
    from werkzeug.security import generate_password_hash

    formulario = RegisterForm()

    if formulario.validate_on_submit():
        usu = formulario.username.data
        sen = generate_password_hash(formulario.password.data)
        # print(f'{usu} - {sen}')

        usuBanco = User.query.filter_by(usuario=usu).first()
        if usuBanco:
            print('usuario ja existe')
        else:
            novoUsuario = User(usuario=usu, senha=sen)
            db.session.add(novoUsuario)
            db.session.commit()
            return redirect(url_for('login'))

    return render_template('register.html', form=formulario)


@app.route('/login', methods=['GET', 'POST'])
def login():
    from forms import LoginForm
    from werkzeug.security import check_password_hash

    formulario = LoginForm()

    if formulario.validate_on_submit():
        usu = formulario.username.data
        usuBanco = User.query.filter_by(usuario=usu).first()

        if usuBanco:
            sen = formulario.password.data
            senhaHash = usuBanco.senha

            if check_password_hash(senhaHash, sen):
                login_user(usuBanco)
                return redirect(url_for('dashboard'))
            # else:
            #    print('erro')

    return render_template('login.html', form=formulario)


@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('login'))


@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    status = request.args.get('status')  # Obtém o status do parâmetro da URL

    # Tarefas criadas pelo usuário logado
    minhas_tarefas_criadas = Tarefa.query.filter_by(user_id=current_user.id).all()

    # Tarefas atribuídas ao usuário logado
    tarefas_atribuidas = Tarefa.query.filter_by(assigned_user_id=current_user.id).all()

    # Combina as listas de tarefas, removendo duplicatas
    todas_as_tarefas = {tarefa.id: tarefa for tarefa in minhas_tarefas_criadas + tarefas_atribuidas}.values()

    if status:
        todas_as_tarefas = [tarefa for tarefa in todas_as_tarefas if tarefa.status == status]

    return render_template('dashboard.html', minhas_tarefas=todas_as_tarefas)





@app.route('/create_event', methods=['GET', 'POST'])
@login_required
def create_event():
    form = TarefaForm()
    form.assigned_user_id.choices = [(user.id, user.usuario) for user in User.query.all()]  # Lista de usuários

    if form.validate_on_submit():
        nova_tarefa = Tarefa(
            titulo=form.titulo.data,
            descricao=form.descricao.data,
            status=form.status.data,
            user_id=current_user.id,  # Criador da tarefa
            assigned_user_id=form.assigned_user_id.data  # Atribui a tarefa a outro usuário
        )
        db.session.add(nova_tarefa)
        db.session.commit()
        return redirect(url_for('dashboard'))

    return render_template('create_event.html', form=form)

@app.route('/edit_event/<int:event_id>', methods=['GET', 'POST'])
@login_required
def edit_event(event_id):
    tarefa = Tarefa.query.get_or_404(event_id)
    if tarefa.user_id != current_user.id:
        return redirect(url_for('dashboard'))

    form = TarefaForm(obj=tarefa)
    form.assigned_user_id.choices = [(user.id, user.usuario) for user in User.query.all()]  # Lista de usuários

    if form.validate_on_submit():
        tarefa.titulo = form.titulo.data
        tarefa.descricao = form.descricao.data
        tarefa.status = form.status.data
        tarefa.assigned_user_id = form.assigned_user_id.data  # Atualiza o usuário atribuído
        db.session.commit()
        return redirect(url_for('dashboard'))

    return render_template('edit_event.html', form=form, tarefa=tarefa)



@app.route('/delete_event/<int:event_id>', methods=['POST'])
@login_required
def delete_event(event_id):
    tarefa = Tarefa.query.get_or_404(event_id)
    if tarefa.user_id != current_user.id:
        return redirect(url_for('dashboard'))

    db.session.delete(tarefa)
    db.session.commit()
    return redirect(url_for('dashboard'))



if __name__ == '__main__':
    app.run(debug=True)

"""
pip install flask, flask-wtf, 
flask_sqlalchemy, flask_login
"""